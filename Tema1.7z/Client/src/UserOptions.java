public enum UserOptions {
    SIGNIN,
    LOGIN,
    FORGOTPASSWORD,
    CANCEL,
    UNDEFINED,
    LOGOUT,
}
