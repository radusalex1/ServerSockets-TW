public class Message {
    private UserOptions content;
    private User user;

    public Message(UserOptions content, User user) {

        this.content = content;
        this.user = user;

    }

    public User getUser() {
        return user;
    }

    @Override
    public String toString() {
        return content+"_"+user.toString();
    }
}
