package org.example;

public enum UserOptions {
    SIGNIN,
    LOGIN,
    FORGOT_PASSWORD,
    CANCEL,
    UNDEFINED,
}
